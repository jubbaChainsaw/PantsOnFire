export const DefaultThemeCardsPromptRoundData = {
  id: 'default-theme-cards',
  name: 'Default Theme Cards',
  emoji: '🔥',
  prompts: [
    {"hint":"Hot Seat: Default Theme Cards sample","main":"Default Theme Cards main","imposter":"Default Theme Cards liar"},
  ],
};
