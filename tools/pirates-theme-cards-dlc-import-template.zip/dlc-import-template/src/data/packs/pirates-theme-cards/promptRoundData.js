export const PiratesThemeCardsPromptRoundData = {
  id: 'pirates-theme-cards',
  name: 'Pirates Theme Cards',
  emoji: '🔥',
  prompts: [
    {"hint":"Hot Seat: Pirates Theme Cards sample","main":"Pirates Theme Cards main","imposter":"Pirates Theme Cards liar"},
  ],
};
